const API = {
  token: localStorage.getItem('nm_token') || '',
  async request(path, options = {}) {
    const headers = {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    };
    if (this.token) headers.Authorization = `Bearer ${this.token}`;
    const res = await fetch(path, { ...options, headers });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Request failed');
    return data;
  }
};

const state = {
  me: null,
  dashboard: null,
  view: 'dashboard',
  stageFilter: 'drop_off',
  consigners: [],
  dropoffs: [],
  items: [],
  pending: [],
  notifications: [],
  reports: [],
  selectedDropoffId: '',
  selectedConsignerId: '',
  selectedReport: null,
  message: '',
  error: '',
  printMode: false
};

const stageLabels = {
  drop_off: 'Drop Off',
  back_of_house: 'Back of House',
  review_cleaning: 'Review & Cleaning',
  photograph: 'Photograph',
  prepare_pickup: 'Prepare for Pick Up',
  picked_up: 'Customer Picked Up'
};

const stages = Object.keys(stageLabels);
const app = document.getElementById('app');

function html(strings, ...values) {
  return strings.reduce((out, str, i) => out + str + (values[i] ?? ''), '');
}
function esc(v) {
  return String(v ?? '').replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
}
function setFlash(message = '', error = '') {
  state.message = message;
  state.error = error;
  render();
  if (message || error) setTimeout(() => { state.message = ''; state.error = ''; render(); }, 3000);
}
function logout() {
  API.token = '';
  localStorage.removeItem('nm_token');
  state.me = null;
  render();
}

async function login(firstName, pin) {
  const data = await API.request('/api/login', {
    method: 'POST',
    body: JSON.stringify({ firstName, pin })
  });
  API.token = data.token;
  localStorage.setItem('nm_token', data.token);
  await bootstrap();
}

async function bootstrap() {
  try {
    state.me = await API.request('/api/me');
    await refreshAll();
  } catch {
    logout();
  }
}

async function refreshAll() {
  const [dashboard, consigners, dropoffs, notifications, reports, pending] = await Promise.all([
    API.request('/api/dashboard'),
    API.request('/api/consigners'),
    API.request('/api/dropoffs'),
    API.request('/api/notifications'),
    API.request('/api/reports'),
    API.request('/api/pending')
  ]);
  state.dashboard = dashboard;
  state.consigners = consigners;
  state.dropoffs = dropoffs;
  state.notifications = notifications;
  state.reports = reports;
  state.pending = pending;
  await loadStageItems(state.stageFilter);
  render();
}

async function loadStageItems(stage) {
  state.stageFilter = stage;
  state.items = await API.request(`/api/items?stage=${encodeURIComponent(stage)}`);
  render();
}

function loginView() {
  return html`
    <div class="login-wrap">
      <form class="login-card" id="loginForm">
        <div class="login-brand">
          <div class="brand">
            <div class="brand-badge">NM</div>
            <div>
              <h1>NM Auctions V5</h1>
              <p>Deployment-ready workflow command center</p>
            </div>
          </div>
        </div>
        <div class="form-grid">
          <div class="full">
            <label>First name</label>
            <input name="firstName" placeholder="Fabian" required />
          </div>
          <div class="full">
            <label>4-digit PIN</label>
            <input name="pin" type="password" inputmode="numeric" maxlength="4" placeholder="1234" required />
          </div>
        </div>
        <div class="small muted" style="margin-top:10px;">All seeded users start at 1234 and must change it after first login.</div>
        ${state.error ? `<div class="error">${esc(state.error)}</div>` : ''}
        <div style="margin-top:18px;"><button type="submit" style="width:100%;">Enter the system</button></div>
      </form>
    </div>`;
}

function topNav() {
  const unread = state.me?.unreadNotifications || 0;
  return html`
  <div class="topbar">
    <div class="brand">
      <div class="brand-badge">NM</div>
      <div>
        <h1>NM Auctions</h1>
        <p>Lots, handoffs, reports, and pickup flow without the clipboard tornado</p>
      </div>
    </div>
    <div class="user-pill">
      <strong>${esc(state.me.user.firstName)}</strong>
      <span class="badge ${state.me.user.isAdmin ? 'gold' : ''}">${state.me.user.isAdmin ? 'Admin' : 'Staff'}</span>
      <span class="badge ${unread ? 'red' : 'green'}">${unread} alerts</span>
      <button class="ghost" onclick="logout()">Log out</button>
    </div>
  </div>
  <div class="nav">
    ${[
      ['dashboard', 'Dashboard'],
      ['intake', 'Intake'],
      ['workflow', 'Workflow'],
      ['pending', 'Approvals'],
      ['reports', 'Daily Reports'],
      ['notifications', 'Notifications'],
      ['employees', 'Employees']
    ].map(([id, label]) => `<button class="${state.view===id?'active':''}" onclick="setView('${id}')">${label}</button>`).join('')}
  </div>`;
}

function dashboardView() {
  const byStage = state.dashboard?.byStage || {};
  return html`
  <div class="stats">
    <div class="stat"><div class="label">Drop Off</div><div class="value tabular">${byStage.drop_off || 0}</div></div>
    <div class="stat"><div class="label">Awaiting Approval</div><div class="value tabular">${state.dashboard?.pendingApprovals || 0}</div></div>
    <div class="stat"><div class="label">Photographed Today</div><div class="value tabular">${state.reports[0]?.payload?.itemCount || 0}</div></div>
  </div>
  <div class="grid">
    <div class="card">
      <div class="card-header"><div><h3 class="section-title">Workflow snapshot</h3><p class="section-sub">Tap a station and jump straight into its items.</p></div></div>
      <div class="card-body list">
        ${stages.map((s) => `
          <button class="secondary" onclick="setView('workflow'); loadStageItems('${s}')" style="display:flex;justify-content:space-between;align-items:center;">
            <span>${stageLabels[s]}</span><strong>${byStage[s] || 0}</strong>
          </button>`).join('')}
      </div>
    </div>
    <div class="card">
      <div class="card-header"><div><h3 class="section-title">Fast actions</h3><p class="section-sub">The buttons your team will actually use.</p></div></div>
      <div class="card-body list">
        <button onclick="setView('intake')">Start a drop off</button>
        <button class="secondary" onclick="setView('pending')">Review incoming approvals</button>
        <button class="secondary" onclick="runCloseout()">Daily close out</button>
        ${state.dashboard?.todayReport ? `<button class="ghost" onclick="openReport('${state.dashboard.todayReport.report_date}')">Open today's report</button>` : ''}
      </div>
    </div>
  </div>`;
}

function intakeView() {
  return html`
  <div class="grid">
    <div class="card">
      <div class="card-header"><div><h3 class="section-title">Create consigner or drop off</h3><p class="section-sub">Shortcodes use first three letters of first and last name.</p></div></div>
      <div class="card-body">
        <form id="consignerForm" class="form-grid">
          <div><label>Consigner first name</label><input name="firstName" required /></div>
          <div><label>Consigner last name</label><input name="lastName" required /></div>
          <div class="full"><button type="submit">Create consigner</button></div>
        </form>
        <hr style="border-color:var(--line);margin:18px 0;">
        <form id="dropoffForm" class="form-grid">
          <div class="full"><label>Select consigner</label>
            <select name="consignerId" required>
              <option value="">Choose a consigner</option>
              ${state.consigners.map(c => `<option value="${c.id}">${esc(c.first_name)} ${esc(c.last_name)} • ${esc(c.shortcode)}</option>`).join('')}
            </select>
          </div>
          <div class="full"><button type="submit" class="secondary">Start drop off</button></div>
        </form>
      </div>
    </div>
    <div class="card">
      <div class="card-header"><div><h3 class="section-title">Add items to a drop off</h3><p class="section-sub">Pick a drop off and start building intake order.</p></div></div>
      <div class="card-body">
        <form id="itemForm" class="form-grid">
          <div class="full"><label>Active drop off</label>
            <select name="dropoffId" required>
              <option value="">Choose a drop off</option>
              ${state.dropoffs.map(d => `<option value="${d.id}">${esc(d.first_name)} ${esc(d.last_name)} • ${esc(d.shortcode)} • ${d.item_count} items</option>`).join('')}
            </select>
          </div>
          <div class="full"><label>Item name</label><input name="name" required /></div>
          <div><label>Dimensions</label><input name="dimensions" placeholder="48x30x28" /></div>
          <div><label>Condition</label><input name="conditionText" placeholder="Good" /></div>
          <div><label>Multi-part total</label><input name="multipartTotal" type="number" min="1" value="1" /></div>
          <div></div>
          <div class="full"><label>Description</label><textarea name="description"></textarea></div>
          <div class="full"><label>Notes</label><textarea name="notes"></textarea></div>
          <div class="full"><button type="submit">Add item</button></div>
        </form>
      </div>
    </div>
  </div>`;
}

function workflowView() {
  return html`
    <div class="toolbar">
      ${stages.map(s => `<button class="${state.stageFilter === s ? '' : 'secondary'}" onclick="loadStageItems('${s}')">${stageLabels[s]}</button>`).join('')}
    </div>
    <div class="card"><div class="card-header"><div><h3 class="section-title">${stageLabels[state.stageFilter]}</h3><p class="section-sub">Move items forward. If a step is skipped, a reason is mandatory.</p></div></div>
    <div class="card-body list">
      ${state.items.length ? state.items.map(itemCard).join('') : '<div class="empty">No items here yet.</div>'}
    </div></div>`;
}

function itemCard(item) {
  const currentIndex = stages.indexOf(item.current_stage);
  const moveButtons = stages.slice(currentIndex + 1).map((stage) => `
    <button class="ghost" onclick="moveItemPrompt('${item.id}','${stage}')">Send to ${stageLabels[stage]}</button>
  `).join('');

  return `
    <div class="item-card">
      <div class="item-top">
        <div>
          <strong>${esc(item.name)}</strong>
          <div class="muted small">${esc(item.consigner_first_name)} ${esc(item.consigner_last_name)} • ${esc(item.consigner_item_code)}</div>
        </div>
        <div class="badges">
          ${item.lot_number ? `<span class="badge gold">Lot ${esc(item.lot_number)}</span>` : ''}
          <span class="badge">${stageLabels[item.current_stage]}</span>
          ${item.awaiting_acceptance ? '<span class="badge red">Waiting approval</span>' : ''}
        </div>
      </div>
      <div class="badges">
        ${item.dimensions ? `<span class="badge">${esc(item.dimensions)}</span>` : ''}
        ${item.condition_text ? `<span class="badge">${esc(item.condition_text)}</span>` : ''}
        ${item.multipart_total > 1 ? `<span class="badge">${item.multipart_total} parts</span>` : ''}
      </div>
      <div class="toolbar" style="margin-top:12px;">
        ${moveButtons}
        <button class="secondary" onclick="viewItem('${item.id}')">View details</button>
        <button class="danger" onclick="deleteItem('${item.id}')">Delete</button>
      </div>
    </div>`;
}

function pendingView() {
  return html`
    <div class="card"><div class="card-header"><div><h3 class="section-title">Incoming handoffs</h3><p class="section-sub">Employees must accept items sent from the previous section.</p></div></div>
      <div class="card-body list">
        ${state.pending.length ? state.pending.map(p => `
          <div class="item-card">
            <div class="row-between">
              <div>
                <strong>${esc(p.name)}</strong>
                <div class="muted small">${esc(p.consigner_item_code)} • ${esc(p.consigner_first_name)} ${esc(p.consigner_last_name)}</div>
              </div>
              <div class="badges">
                <span class="badge">${stageLabels[p.pending_from_stage]} → ${stageLabels[p.pending_to_stage]}</span>
                ${p.pending_reason ? `<span class="badge gold">Reason: ${esc(p.pending_reason)}</span>` : ''}
              </div>
            </div>
            <div class="toolbar" style="margin-top:12px;">
              <button class="good" onclick="acceptItem('${p.id}')">Accept</button>
              <button class="danger" onclick="rejectItem('${p.id}')">Reject</button>
              <button class="secondary" onclick="viewItem('${p.id}')">Details</button>
            </div>
          </div>`).join('') : '<div class="empty">Nothing waiting right now.</div>'}
      </div>
    </div>`;
}

function reportsView() {
  return html`
    <div class="grid">
      <div class="card">
        <div class="card-header"><div><h3 class="section-title">Daily close out</h3><p class="section-sub">Stores that day's photographed items in the order they were photographed.</p></div></div>
        <div class="card-body list">
          <button onclick="runCloseout()">Run close out for today</button>
          <div class="print-note">A printable report opens immediately after close out. Reports stay stored by day for all employees.</div>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><div><h3 class="section-title">Saved reports</h3><p class="section-sub">Newest first.</p></div></div>
        <div class="card-body list">
          ${state.reports.length ? state.reports.map(r => `<button class="secondary" onclick="openReport('${r.report_date}')">${esc(r.report_date)} • ${r.payload.itemCount} items • closed by ${esc(r.closed_by_name)}</button>`).join('') : '<div class="empty">No reports saved yet.</div>'}
        </div>
      </div>
    </div>
    ${state.selectedReport ? reportPreview(state.selectedReport) : ''}`;
}

function reportPreview(report) {
  const p = report.payload;
  return html`
    <div class="card" style="margin-top:18px;">
      <div class="card-header"><div><h3 class="section-title">Preview</h3><p class="section-sub">Regular printer paper format.</p></div><button onclick="window.print()">Print report</button></div>
      <div class="card-body"><div class="report-page print-shell">
        <h1 style="margin:0 0 6px;">NM Auctions</h1>
        <h2 style="margin:0 0 18px;font-size:1.25rem;">Daily Lot Report</h2>
        <div style="margin-bottom:24px;">${esc(p.reportDate)}<br>${p.itemCount} photographed item${p.itemCount===1?'':'s'}</div>
        ${p.items.length ? p.items.map((item) => `
          <div class="report-item">
            <div><strong>Lot ${esc(item.lotNumber || 'Pending')}</strong></div>
            <div>Item: ${esc(item.item || '')}</div>
            <div>Dimensions: ${esc(item.dimensions || '')}</div>
            <div>Condition: ${esc(item.condition || '')}</div>
            <div>Notes: ${esc(item.notes || '')}</div>
          </div>`).join('') : '<div>No photographed items for this date.</div>'}
      </div></div>
    </div>`;
}

function notificationsView() {
  return html`
    <div class="card"><div class="card-header"><div><h3 class="section-title">Notifications</h3><p class="section-sub">Push-style handoff alerts live here.</p></div><button onclick="markNotificationsRead()">Mark all read</button></div>
      <div class="card-body list">
        ${state.notifications.length ? state.notifications.map(n => `<div class="item-card"><div class="row-between"><div>${esc(n.message)}</div><span class="badge ${n.is_read ? '' : 'red'}">${n.is_read ? 'Read' : 'Unread'}</span></div><div class="muted small">${esc(n.created_at)}</div></div>`).join('') : '<div class="empty">No notifications.</div>'}
      </div>
    </div>`;
}

function employeesView() {
  return html`
    <div class="grid">
      <div class="card">
        <div class="card-header"><div><h3 class="section-title">Employees</h3><p class="section-sub">Admins can add staff and toggle admin access.</p></div></div>
        <div class="card-body list">
          ${state.me.user.isAdmin ? `<form id="employeeForm" class="form-grid">
            <div><label>First name</label><input name="firstName" required /></div>
            <div><label>Role</label><select name="isAdmin"><option value="0">Staff</option><option value="1">Admin</option></select></div>
            <div class="full"><button type="submit">Add employee</button></div>
          </form><hr style="border-color:var(--line);margin:18px 0;">` : ''}
          <div id="employeeList">Loading…</div>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><div><h3 class="section-title">PIN safety</h3><p class="section-sub">Every new employee starts at 1234 and must change it at first login.</p></div></div>
        <div class="card-body">
          <form id="pinForm" class="form-grid">
            <div class="full"><label>Change my PIN</label><input name="newPin" inputmode="numeric" maxlength="4" placeholder="4 digits" required /></div>
            <div class="full"><button type="submit" class="secondary">Update PIN</button></div>
          </form>
        </div>
      </div>
    </div>`;
}

async function renderEmployeesList() {
  const employees = await API.request('/api/employees');
  const el = document.getElementById('employeeList');
  if (!el) return;
  el.innerHTML = employees.map(e => `
    <div class="item-card">
      <div class="row-between">
        <div><strong>${esc(e.firstName)}</strong><div class="muted small">${e.forcePinChange ? 'Needs PIN change' : 'PIN set'}</div></div>
        <div class="inline">
          <span class="badge ${e.isAdmin ? 'gold' : ''}">${e.isAdmin ? 'Admin' : 'Staff'}</span>
          ${state.me.user.isAdmin ? `<button class="ghost" onclick="toggleAdmin('${e.id}', ${e.isAdmin ? 0 : 1})">Make ${e.isAdmin ? 'Staff' : 'Admin'}</button>` : ''}
        </div>
      </div>
    </div>`).join('');
}

function shellView() {
  return html`<div class="layout">
    ${topNav()}
    ${state.message ? `<div class="success">${esc(state.message)}</div>` : ''}
    ${state.error ? `<div class="error">${esc(state.error)}</div>` : ''}
    ${state.me.user.forcePinChange ? `<div class="card" style="margin-bottom:18px;"><div class="card-body"><strong>PIN change required.</strong> Use the Employees tab before doing anything else.</div></div>` : ''}
    ${state.view === 'dashboard' ? dashboardView() : ''}
    ${state.view === 'intake' ? intakeView() : ''}
    ${state.view === 'workflow' ? workflowView() : ''}
    ${state.view === 'pending' ? pendingView() : ''}
    ${state.view === 'reports' ? reportsView() : ''}
    ${state.view === 'notifications' ? notificationsView() : ''}
    ${state.view === 'employees' ? employeesView() : ''}
  </div>`;
}

function render() {
  app.innerHTML = state.me ? shellView() : loginView();

  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.onsubmit = async (e) => {
      e.preventDefault();
      const fd = new FormData(loginForm);
      try {
        await login(fd.get('firstName'), fd.get('pin'));
        setFlash('Welcome back.');
      } catch (err) {
        state.error = err.message;
        render();
      }
    };
  }

  const consignerForm = document.getElementById('consignerForm');
  if (consignerForm) consignerForm.onsubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData(consignerForm);
    try {
      await API.request('/api/consigners', { method: 'POST', body: JSON.stringify(Object.fromEntries(fd)) });
      await refreshAll();
      setFlash('Consigner created.');
      consignerForm.reset();
    } catch (err) { setFlash('', err.message); }
  };

  const dropoffForm = document.getElementById('dropoffForm');
  if (dropoffForm) dropoffForm.onsubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData(dropoffForm);
    try {
      const data = await API.request('/api/dropoffs', { method: 'POST', body: JSON.stringify(Object.fromEntries(fd)) });
      await refreshAll();
      setFlash(`Drop off started. ID ${data.id}`);
      dropoffForm.reset();
    } catch (err) { setFlash('', err.message); }
  };

  const itemForm = document.getElementById('itemForm');
  if (itemForm) itemForm.onsubmit = async (e) => {
    e.preventDefault();
    const fd = Object.fromEntries(new FormData(itemForm));
    fd.multipartTotal = Number(fd.multipartTotal || 1);
    try {
      const data = await API.request('/api/items', { method: 'POST', body: JSON.stringify(fd) });
      await refreshAll();
      setFlash(`Item added: ${data.consignerItemCode}`);
      itemForm.reset();
    } catch (err) { setFlash('', err.message); }
  };

  const pinForm = document.getElementById('pinForm');
  if (pinForm) pinForm.onsubmit = async (e) => {
    e.preventDefault();
    const newPin = new FormData(pinForm).get('newPin');
    try {
      await API.request('/api/change-pin', { method: 'POST', body: JSON.stringify({ newPin }) });
      const me = await API.request('/api/me');
      state.me = me;
      render();
      setFlash('PIN updated.');
    } catch (err) { setFlash('', err.message); }
  };

  const employeeForm = document.getElementById('employeeForm');
  if (employeeForm) employeeForm.onsubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData(employeeForm);
    try {
      await API.request('/api/employees', { method: 'POST', body: JSON.stringify({ firstName: fd.get('firstName'), isAdmin: fd.get('isAdmin') === '1' }) });
      await renderEmployeesList();
      employeeForm.reset();
      setFlash('Employee added with PIN 1234.');
    } catch (err) { setFlash('', err.message); }
  };

  if (state.view === 'employees' && state.me) renderEmployeesList();
}

async function setView(view) { state.view = view; render(); if (view === 'employees') await renderEmployeesList(); }
async function toggleAdmin(id, isAdmin) {
  try { await API.request(`/api/employees/${id}`, { method: 'PATCH', body: JSON.stringify({ isAdmin: !!isAdmin }) }); await renderEmployeesList(); setFlash('Role updated.'); } catch (err) { setFlash('', err.message); }
}
async function moveItemPrompt(id, toStage) {
  const reason = prompt(`Send item to ${stageLabels[toStage]}?\nIf you are skipping a step, type the reason here. Leave blank for normal next-step moves.`) ?? '';
  try { await API.request(`/api/items/${id}/move`, { method: 'POST', body: JSON.stringify({ toStage, reason }) }); await refreshAll(); setFlash('Item sent for approval.'); } catch (err) { setFlash('', err.message); }
}
async function acceptItem(id) {
  try {
    const data = await API.request(`/api/items/${id}/accept`, { method: 'POST' });
    await refreshAll();
    setFlash(data.lotNumber ? `Accepted. Assigned lot ${data.lotNumber}.` : 'Accepted.');
  } catch (err) { setFlash('', err.message); }
}
async function rejectItem(id) { try { await API.request(`/api/items/${id}/reject`, { method: 'POST' }); await refreshAll(); setFlash('Handoff rejected.'); } catch (err) { setFlash('', err.message); } }
async function deleteItem(id) {
  if (!confirm('Delete this item?')) return;
  try { await API.request(`/api/items/${id}`, { method: 'DELETE' }); await refreshAll(); setFlash('Item deleted.'); } catch (err) { setFlash('', err.message); }
}
async function viewItem(id) {
  try {
    const data = await API.request(`/api/items/${id}`);
    const remaining = data.relatedItems.map(i => `${i.consigner_item_code} • ${i.name} • ${stageLabels[i.current_stage]}`).join('\n');
    alert([
      `Item: ${data.item.name}`,
      `Consigner: ${data.item.consigner_first_name} ${data.item.consigner_last_name}`,
      `Code: ${data.item.consigner_item_code}`,
      `QR: ${data.item.qr_code}`,
      data.item.lot_number ? `Lot: ${data.item.lot_number}` : '',
      '',
      'Remaining items for this consigner:',
      remaining
    ].filter(Boolean).join('\n'));
  } catch (err) { setFlash('', err.message); }
}
async function runCloseout() {
  try {
    const data = await API.request('/api/reports/daily-closeout', { method: 'POST', body: JSON.stringify({}) });
    state.selectedReport = { payload: data.payload };
    state.view = 'reports';
    await refreshAll();
    state.selectedReport = { payload: data.payload };
    render();
    setTimeout(() => window.print(), 300);
    setFlash('Daily close out complete.');
  } catch (err) { setFlash('', err.message); }
}
async function openReport(date) {
  try { state.selectedReport = await API.request(`/api/reports/${date}`); state.view = 'reports'; render(); } catch (err) { setFlash('', err.message); }
}
async function markNotificationsRead() { try { await API.request('/api/notifications/read-all', { method: 'POST' }); state.me = await API.request('/api/me'); state.notifications = await API.request('/api/notifications'); render(); setFlash('Notifications marked read.'); } catch (err) { setFlash('', err.message); } }

window.logout = logout;
window.setView = setView;
window.loadStageItems = loadStageItems;
window.moveItemPrompt = moveItemPrompt;
window.acceptItem = acceptItem;
window.rejectItem = rejectItem;
window.deleteItem = deleteItem;
window.viewItem = viewItem;
window.runCloseout = runCloseout;
window.openReport = openReport;
window.markNotificationsRead = markNotificationsRead;
window.toggleAdmin = toggleAdmin;

render();
bootstrap();
